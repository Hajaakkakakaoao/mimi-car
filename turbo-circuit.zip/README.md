# Turbo Circuit

A 2D top-down racing game. Single HTML file, no libraries, no build step.

## Controls
- Arrow keys or WASD to drive
- Space to brake and drift
- On phones, on-screen buttons appear

## Play online with GitHub Pages
1. Upload these files to a new GitHub repository (Add file > Upload files).
2. Go to Settings > Pages.
3. Under Build and deployment, choose Deploy from a branch, pick `main` and `/ (root)`, then Save.
4. After about a minute your game is live at `https://YOUR-USERNAME.github.io/YOUR-REPO/`.

## Play locally
Double-click `index.html`.
